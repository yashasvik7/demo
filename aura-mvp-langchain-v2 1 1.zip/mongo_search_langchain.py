# import json
# import os
# # os.chdir('/home/user/app')
# from dotenv import load_dotenv,find_dotenv
# load_dotenv(find_dotenv())
# from langchain.embeddings import HuggingFaceEmbeddings
# import glob
# from bson.objectid import ObjectId
# from pymongo.mongo_client import MongoClient

# from langchain.chains import RetrievalQA
# from langchain_community.vectorstores import MongoDBAtlasVectorSearch
# from doc_prompt import prompt_template

# from config import *
# from langchain.prompts import PromptTemplate
# from langchain.chains import LLMChain
# from sentence_transformers import SentenceTransformer

# embeddings = HuggingFaceEmbeddings(model_name='pkshatech/GLuCoSE-base-ja')
# search = MongoDBAtlasVectorSearch(docs_coll, embeddings, index_name=mongo_index_name, text_key='Content', embedding_key='Content_vector')
# local_llm = llm_for_search


# data_form = "Document(page_content = 'Contents' , metadata= {metadata': {'source': 'Source file', creation_date: 'Create Date', 'page_no': 'Page Number' ..}})"

# example1 = """
# [Document(page_content = Contents_1 , metadata= {metadata': {'source': Source_File_1, creation_date: Created_Date_1, 'page_no': Page_Number_1 ..}})
# Document(page_content = Contents_2 , metadata= {metadata': {'source': Source_File_2, creation_date: Created_Date_2, 'page_no': Page_Number_2 ..}})
# Document(page_content = Contents_3 , metadata= {metadata': {'source': Source_File_3, creation_date: Created_Date_3, 'page_no': Page_Number_3 ..}})
# Document(page_content = Contents_4 , metadata= {metadata': {'source': Source_File_4, creation_date: Created_Date_4, 'page_no': Page_Number_4 ..}})]
# """


# PROMPT = PromptTemplate(
#     template=prompt_template, input_variables=["context", "question"]
# )



# def mongo_find_old(question_txt, checksums):

#     # encoded_query = embeddings.embed_query(question_txt)
#     encoded_query = embeddings.embed_query(question_txt)

#     vector_query = {
#                 "queryVector": encoded_query,
#                 "path": "Content_vector",
#                 "numCandidates": 150,
#                 "limit": 15,
#                 "index": mongo_index_name,
#             }

#     if checksums:
#         query_filter = {"metadata.checksum": {"$in": checksums}}
#         vector_query['filter'] = query_filter

#     pipeline = [
#         {"$vectorSearch": vector_query
#         },
#         {"$set": {"score": {"$meta": "vectorSearchScore"}}},
#         {'$unset': ['Content_vector', '_id']}, {'$limit': 6}]

#     results = list(docs_coll.aggregate(pipeline))

#     contexts = '\n'

#     for res in results:
#         metadata = res['metadata']
#         pg_no = metadata.get('page_no',None)
#         file_nm = metadata.get('source',None)
#         creation_dt = metadata.get('creation_date', None)

#         for info_inp in [file_nm,pg_no,creation_dt]:
#             if info_inp is not None:
#                 contexts += str(info_inp) + ', '
#             else:
#                 contexts += 'NA' + ', '

#         contexts = contexts[:-2] + ' : ' + res['Content'] + "\n\n"

#     llm_chain = LLMChain(prompt=PROMPT, llm=local_llm)

#     llm_ans = llm_chain.run({"context":contexts, "question":question_txt})
#     print(f"Retrieved content : {contexts}")
#     print(llm_ans)

#     return llm_ans

#print(mongo_find(question_txt))



# gemini embedding
import pymongo
import vertexai
from langchain.schema import Document
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_google_vertexai import ChatVertexAI
from langchain.chains import create_history_aware_retriever
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.vectorstores import MongoDBAtlasVectorSearch
# from llama_index.embeddings.gemini import GeminiEmbedding
# from llama_index.llms.gemini import Gemini

#store = {}

# os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "capgemini-aura-41aa57a9cd77.json"
GOOGLE_API_KEY = "AIzaSyCDZlEZgLzluxb9mnR9NdIqN_8UZNdfqrg"
# vertexai.init(project='capgemini-aura', location='us-central1')

    
def mongo_find_langchain(query,checksums,store:dict):
    def get_session_history(session_id: str) -> BaseChatMessageHistory:
        if session_id not in store:
            store[session_id] = ChatMessageHistory()
        return store[session_id]
    # MONGO_URI = "mongodb+srv://Rahul:YoAbz5j9hN4l0A0f@cluster0.80157cr.mongodb.net/?retryWrites=true&w=majority"
    MONGO_URI = "mongodb+srv://austintian:OwTqe5UYQKk3SYDi@aura-llamaindex-test.fvaatww.mongodb.net/?retryWrites=true&w=majority&appName=aura-llamaindex-test"
    # mongo_uri = "mongodb+srv://austintian:OwTqe5UYQKk3SYDi@aura-llamaindex-test.fvaatww.mongodb.net/?retryWrites=true&w=majority&appName=aura-llamaindex-test"
    db_name = "aura-llamaindex-test"
    collection_name = "gemini_embeddings_index"
    # db_name = "aura-llamaindex-test"
    # collection_name = "gemini_embeddings_index"
    client = pymongo.MongoClient(MONGO_URI)
    dbobj = client[db_name]
    docs_coll  = dbobj[collection_name]
    collection = docs_coll.find(filter={})
    documents = list(collection)

    # mongo_db_name = "aura-llamaindex-test"  
    # mongo_docs_collection = "gemini_embeddings_index"
    # mongo_index_name = "vector_index"

    # docs = [Document(page_content=item["Content"],
    #                  metadata={"metadata": item["metadata"]})
    #         for item in documents]

    # genyoda.py
    vector_search = MongoDBAtlasVectorSearch.from_connection_string(
        MONGO_URI,
        db_name + "." + collection_name,
        VertexAIEmbeddings(model_name="textembedding-gecko@latest",api_key=GOOGLE_API_KEY),
    #     GeminiEmbedding(model_name="models/embedding-001", api_key=GOOGLE_API_KEY),
        index_name="vector_index",
    )

    retriever = vector_search.as_retriever(search_type='similarity',
    search_kwargs={
        'k': 10})


    llm = ChatVertexAI(
        model="gemini-1.5-flash-001",api_key=GOOGLE_API_KEY,
        temperature=0,
        max_tokens=None,
        max_retries=6,
        stop=None,
        # other params...
    )


    # chat history is just a dict in memory and is passed inside the prompt when needed. So the longer the history, the more token you will send to the LLM, 
    # the more expensive it will be. there's a standard way to make it take less tokens -  conversation summerization. 

    ### Contextualize question ###
    contextualize_q_system_prompt = (
    """Given:

    A conversation history (chat history)
    The latest user's question
    Task:
    Formulate a standalone question: Based on the chat history and the user's question, create a new question that can be understood by someone who has not 
    seen the chat history.
    Focus on context: The new question should clearly reference the context provided in the chat history, even though the history itself won't be shown.
    No pre-trained knowledge: Do not use the LLM's pre-trained knowledge to answer the question or reformulate it.
    No external sources: Do not access any information beyond the provided chat history.
    Factual response: Provide a standalone question as the output, based solely on the facts and context in the chat history.
    Avoid assumptions: Don't make any assumptions about the conversation or introduce details not explicitly mentioned in the provided context.
    Essentially, you're asked to take a conversation and the latest question, and create a new question that captures the essence of what the user is asking, 
    without revealing the details of the conversation itself.
    Do not rely on any prior knowledge.
    Avoid using web search.
    """
    )
    contextualize_q_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", contextualize_q_system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
        ]
    )
    history_aware_retriever = create_history_aware_retriever(
        llm, retriever, contextualize_q_prompt
    )


    ### Answer question ###
    system_prompt = (
    """Task: As a Capgemini chat expert assistant,answer the questions using only the provided context:

    Answer Format:

    Provide an answer based solely on the information in the provided context.
    If you cannot find an answer within the context, state that you don't know.
    Do not:
    Use your pre-trained knowledge or access external information.
    Make assumptions or introduce details not explicitly mentioned in the provided context.
    In essence, you are asked to act as a factual information retriever, using only the provided documents to answer the user's question.
    Do not rely on any prior knowledge.
    Avoid using web search."""
        "\n\n"
        "{context}"
    )
    qa_prompt = ChatPromptTemplate.from_messages(
      [
            ("system", system_prompt),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
        ]
    )
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)

    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)

    conversational_rag_chain = RunnableWithMessageHistory(
        rag_chain,
        get_session_history,
        input_messages_key="input",
        history_messages_key="chat_history",
        output_messages_key="answer",
    )

#     print('chain invoked')
    result = conversational_rag_chain.invoke(
        {"input": query},
        config={"configurable": {"session_id": "abc123"}},
    )
    #print(result['answer'],'\n',result)
    return result,store