from pymongo.mongo_client import MongoClient
# from llama_index.llms.gemini import Gemini
# import vertexai
# from vertexai.generative_models import GenerativeModel, Part, FinishReason
# import vertexai.preview.generative_models as generative_models

# mongo_uri = "mongodb+srv://Rahul:YoAbz5j9hN4l0A0f@cluster0.80157cr.mongodb.net/?retryWrites=true&w=majority"
#mongo_uri = "mongodb+srv://capgemini:capgemini@atlascluster.eihlgpc.mongodb.net/?retryWrites=true&w=majority"

# mongo_db_name = 'aura_demo_v1' # 'aura_v1'  # 'metlife_japan'
# mongo_docs_collection = 'documents'
# mongo_docs_cksum = 'checksums'
# mongo_index_name = 'aura_demo_v1_search'

# mongo_uri = "mongodb+srv://austintian:OwTqe5UYQKk3SYDi@aura-llamaindex-test.fvaatww.mongodb.net/?retryWrites=true&w=majority&appName=aura-llamaindex-test"
# #

# mongo_db_name = "aura-llamaindex-test"  
# mongo_docs_collection = "gemini_embeddings_index"
# mongo_index_name = "vector_index"

mongo_uri = "mongodb+srv://austintian:OwTqe5UYQKk3SYDi@aura-llamaindex-test.fvaatww.mongodb.net/?retryWrites=true&w=majority&appName=aura-llamaindex-test"
 
mongo_db_name = "aura-llamaindex-test"  
mongo_docs_collection = "gemini_embeddings_index"
mongo_index_name = "vector_index" 
 



# # vertexai.init(project="capgemini-THOR", location="us-central1")
# llm_for_search = AzureChatOpenAI(
#         deployment_name="genyoda35",
#         model_name="gpt-35-turbo",
#         openai_api_key='0e1c91cf40fc4432a9da9d3d4b493dc4',
#         openai_api_version='2023-07-01-preview',
#         azure_endpoint='https://genai-cube.openai.azure.com/',
#         temperature=0.01,
#         max_tokens=4000
#     )

# GOOGLE_API_KEY = "AIzaSyCDZlEZgLzluxb9mnR9NdIqN_8UZNdfqrg"
# llm_for_search = Gemini(model="models/gemini-1.5-flash-001",
#                         api_key=GOOGLE_API_KEY,
#                         temperature=0.2)

# model = GenerativeModel(
#     "gemini-1.5-flash-001",
# )

# generation_config = {
#     "max_output_tokens": 8192,
#     "temperature": 0.1,
#     "top_p": 0.95,
# }

# llm_for_search = model.generate_content(generation_config=generation_config)

upload_files_limit = 2

dbobj = None
docs_coll  = None
cksum_coll = None


def init_db():
    # from pymongo.server_api import ServerApi
    # Create a new client and connect to the server
    uri = mongo_uri
    client = MongoClient(uri)
    # Send a ping to confirm a successful connection
    try:
        client.admin.command('ping')
        print("Pinged your deployment. You successfully connected to MongoDB!")
    except Exception as e:
        print(e)

    global dbobj
    global docs_coll
    #global cksum_coll

    dbobj = client[mongo_db_name]
    docs_coll  = dbobj[mongo_docs_collection]
    #cksum_coll = dbobj[mongo_docs_cksum]
    #return

init_db()
