from fastapi import FastAPI,UploadFile,File,Request
from typing import Optional,Union
import uvicorn
# from mongo_search import mongo_find
#from mongo_search_llamaindex import mongo_find_llama
from pydantic import Json
from config import *
from fastapi.middleware.cors import CORSMiddleware
# from mql_mongo_claude import get_db_result,generate_title
# from split import get_graph_data
# from llama_index.core.memory import ChatMemoryBuffer
from mongo_search_langchain import mongo_find_langchain

# import pandas as pd
# from genyoda_main_ai import call_openai
# from genyoda_main_mongo import get_answer
# from io import BytesIO

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Update this with your frontend origins
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)
app.store={}
@app.get("/")
async def root():
    return {"message": "Hello World"}

# @app.get("/query")
# async def query_genyoda(prompt: str, checksum: Union[Json, None]=None):
#     response = dict()
#     response['prompt'] = prompt

#     response['result'] = mongo_find(prompt, checksum)
#  #   response['result'].replace('\n','<br>')
#     return response

@app.get("/querylangchain")
async def query_genyoda_langchain(request:Request,prompt: str, checksum: Union[Json, None]=None):
    response = dict()
    response['prompt'] = prompt
    store=request.app.store
    answer, store = mongo_find_langchain(prompt, checksum, store)
    print(answer)
    print(store)
    source = '\nSource : '
    for i in answer['context']:
        source = source +'\n' + i.metadata['metadata']['source'] + "\tPage Number : " + i.metadata['metadata']['page_no'] + ', '
        # print('Source : ', i.metadata['metadata']['source'] + "\tPage Number : " + i.metadata['metadata']['page_no'])
    response['result'] = answer['answer'] + source
    
 #   response['result'].replace('\n','<br>')
    return response

# @app.get("/askdatabase")
# async def askdatabase_genyoda(prompt: str):
#     response = dict()
#     response['prompt'] = prompt
#     # Convert the sentence to lower case to handle case insensitivity
#     sentence_lower = prompt.lower()
    
#     # Check if the words "chart" or "graph" are in the sentence
#     if "chart" in sentence_lower or "graph" in sentence_lower:
#         given_text = get_db_result(prompt)
#         title = generate_title(prompt)
#         print("title",title)
#         response['result'] = get_graph_data(given_text,prompt,title)
#     else:
#         response['result'] = get_db_result(prompt)
#  #   response['result'].replace('\n','<br>')
#     return response

#@app.get("/queryllama")
#async def query_genyoda_llama(prompt: str, checksum: Union[Json, None]=None):
#    response = dict()
#    response['prompt'] = prompt

    # fixing temporarily
#    memory = ChatMemoryBuffer.from_defaults(token_limit=3900)
#    response['result'], memory = mongo_find_llama(prompt, checksum, memory)
 #   response['result'].replace('\n','<br>')
 #   return response



# if __name__ == "__main__":
#     uvicorn.run("genyoda_api:app", host="127.0.0.1", port=5000, log_level="info")