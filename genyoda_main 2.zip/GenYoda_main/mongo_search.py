import json
import os
# os.chdir('/home/user/app')
from dotenv import load_dotenv,find_dotenv
load_dotenv(find_dotenv())
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
import glob
from bson.objectid import ObjectId
from pymongo.mongo_client import MongoClient

from langchain.chains import RetrievalQA
from langchain.vectorstores.mongodb_atlas import MongoDBAtlasVectorSearch
from doc_prompt import prompt_template

from config import *
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain


embeddings = HuggingFaceEmbeddings()
search = MongoDBAtlasVectorSearch(docs_coll, embeddings, index_name=mongo_index_name, text_key='Content', embedding_key='Content_vector')
local_llm = llm_for_search


data_form = "Document(page_content = 'Contents' , metadata= {metadata': {'source': 'Source file', creation_date: 'Create Date', 'page_no': 'Page Number' ..}})"

example1 = """
[Document(page_content = Contents_1 , metadata= {metadata': {'source': Source_File_1, creation_date: Created_Date_1, 'page_no': Page_Number_1 ..}})
Document(page_content = Contents_2 , metadata= {metadata': {'source': Source_File_2, creation_date: Created_Date_2, 'page_no': Page_Number_2 ..}})
Document(page_content = Contents_3 , metadata= {metadata': {'source': Source_File_3, creation_date: Created_Date_3, 'page_no': Page_Number_3 ..}})
Document(page_content = Contents_4 , metadata= {metadata': {'source': Source_File_4, creation_date: Created_Date_4, 'page_no': Page_Number_4 ..}})]
"""

# ,partial_variables={"data_format": data_form,'example1':example1}

PROMPT = PromptTemplate(
    template=prompt_template, input_variables=["context", "question"]
)


def mongo_find(question_txt, checksums):

    encoded_query = embeddings.embed_query(question_txt)

    vector_query = {
                "queryVector": encoded_query,
                "path": "Content_vector",
                "numCandidates": 150,
                "limit": 15,
                "index": mongo_index_name,
            }

    if checksums:
        query_filter = {"metadata.checksum": {"$in": checksums}}
        vector_query['filter'] = query_filter

    pipeline = [
        {"$vectorSearch": vector_query
        },
        {"$set": {"score": {"$meta": "vectorSearchScore"}}},
        {'$unset': ['Content_vector', '_id']}, {'$limit': 5}]

    results = list(docs_coll.aggregate(pipeline))

    contexts = '\n'

    for res in results:
        metadata = res['metadata']
        pg_no = metadata.get('page_no',None)
        file_nm = metadata.get('source',None)
        creation_dt = metadata.get('creation_date', None)

        for info_inp in [file_nm,pg_no,creation_dt]:
            if info_inp is not None:
                contexts += str(info_inp) + ', '
            else:
                contexts += 'NA' + ', '

        contexts = contexts[:-2] + ' : ' + res['Content'] + "\n\n"

    llm_chain = LLMChain(prompt=PROMPT, llm=local_llm)

    llm_ans = llm_chain.run({"context":contexts, "question":question_txt})
    print(f"Retrieved content : {contexts}")
    print(llm_ans)

    return llm_ans

#print(mongo_find(question_txt))