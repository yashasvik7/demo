import os
# os.chdir('/home/user/app')
import requests
import json
from mql_prompt import mql_prompt
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from config import *
from pymongo.mongo_client import MongoClient

llm = llm_for_search

uri = mongo_uri

client = MongoClient(uri)
# Send a ping to confirm a successful connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

db = client['vehicle_ins']


# coll = db['all']

def get_query_llm():
    prompt_db_rt = mql_prompt + """

Question: {question}

Assistant:"""

    eg1 = r'{"$match": {"string_field": {"$regex": "^value$", "$options": "i"}}}'
    eg2 = r'{"$match": {"string_field": {"$regex": "value", "$options": "i"}}}'
    eg3 = r'{"$match":{"number or float_field":"value"}}'
    op_format = '''{
Reference:Reference of fields used with dtype,
output: base collection Query,
base_collection:name
}'''

    prompt_db_1 = PromptTemplate(template=prompt_db_rt, input_variables=['question'],
                                 partial_variables={'eg1': eg1, 'eg2': eg2,
                                                    'eg3': eg3, 'op_format': op_format})

    llm_chain_db = LLMChain(prompt=prompt_db_1, llm=llm)

    return llm_chain_db


def clean_query(llm_op):
    start_char = llm_op.find('{')
    end_char = min(llm_op.rfind('}')+1,len(llm_op))

    try:
        op_dict = json.loads(llm_op[start_char:end_char].strip().replace('True','true').replace('False','false'))
    except:
        op_dict = {"Error": 'Error in transforming query'}

    return op_dict


def exec_mongo_query(query, coll_name):
    final_result = []
    print(query)
    print(coll_name)
    coll = db[coll_name]
    res = coll.aggregate(query)
    for i in res:
        final_result.append(i)

    return str({'query_result': final_result})


def get_final_result(op_mongo, user_ques):
    prompt_query_res = """Human: You are an helpful assistant who can interpret output of mongodb query.
    Answer question given below just by formatting the below mongo result which is output of question asked below
    Output result should be well formatted, provide answer in bullet format if required, do not make up any answer.
    Do not provide any of your conclusion.

    Mongo result:
    {result}

    Question: {question}

    Assistant:"""

    prompt_res_1 = PromptTemplate(template=prompt_query_res, input_variables=['question'],
                                  partial_variables={'result': op_mongo})

    llm_chain_db = LLMChain(prompt=prompt_res_1, llm=llm)

    final_result = llm_chain_db(user_ques)

    return final_result['text']


def get_db_result(user_inp):
    generate_query = get_query_llm()

    res = generate_query(user_inp)
    # res = generate_query('for customer id c18 provide details of its name, policy number ,all coverage amount,expiry date,vehicle model, year, driver licence number')
    print(res['text'])

    op_query = clean_query(res['text'])

    if 'Error' not in op_query.keys():
        query_result = exec_mongo_query(op_query['output'], op_query['base_collection'])

        final_chain = get_final_result(query_result, user_inp)

        print(final_chain)
        return final_chain
    else:
        return op_query['Error']

