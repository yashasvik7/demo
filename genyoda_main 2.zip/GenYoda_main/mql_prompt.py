mql_prompt = '''
Human: Act as a PyMongo expert and write queries from natural language that i can execute with python . I will request query requests that will be executed with python, via pymongo, based on requests in natural language. Requests can contain query statements that return simple data or summaries of sums and calculations of document attributes. They may involve one or more collections. A query request is composed of the Query syntax of Python aggregate pipeline like all keys of json in quotes, a title definition that relates the result field with a presentation title (this list should only indicate the fields returned in the query), and an indication of the base collection for the query.Perform joins if fields are in multiple collection.

The available collections of DB and their attributes are listed below, in a simplified form with their data type:
Collection_name : Attributes (datatype)

1) customer : [
            CustomerID (TEXT), First Name (TEXT), Last Name (TEXT), Street1 (TEXT), 
            Street2 (TEXT), City (TEXT), State (TEXT),
            Zip (FLOAT), 
            Latitude (FLOAT), Longitude (FLOAT), Coverage (TEXT), 
            Date of Birth (TIMESTAMP), Education (TEXT), EmploymentStatus (TEXT), 
            Gender (TEXT), Income (FLOAT), Marital Status (TEXT), Standard Vehicle ID (TEXT), 
            Antique Vehicle ID (TEXT), MVR ID (TEXT), PolicyNumber (TEXT), 
            CLUEID (TEXT), MissingPolicyIndicator (TEXT), DrivingHistoryIndicator (TEXT)
            ]


2) policy : [
            PolicyNumber (TEXT), Coverage (TEXT), Policy Type (TEXT), 
            Policy (TEXT), Monthly Premium Auto (INTEGER), Months Since Last Claim (INTEGER), 
            Months Since Policy Inception (INTEGER), Number of Open Complaints (INTEGER), 
            Number of Policies (INTEGER), Policy Status (FLOAT), Term Effective Date (TIMESTAMP-Date), 
            Term Expiry Date (TIMESTAMP-Date), Bodily Injury Coverage Occurrence (INTEGER), 
            Bodily Injury Coverage Aggregate (INTEGER), Medical Payments Coverage (INTEGER), 
            Physical Damage Coverage (INTEGER), UnInsured Motorist BI Occurrence (INTEGER), 
            UnInsured Motorist BI Aggregate (INTEGER), UnInsured Motorist PD (INTEGER)
            ]

3) mvr_driver : [
            MVRID (TEXT), DLN Number (TEXT), DLN Issued (TIMESTAMP),
            DLN Expired (TIMESTAMP), Violation (TEXT),
            Violation Tenure (in Months) (INTEGER), Violation Reason (TEXT)
            ]

4) household_income : [
            Zip (INTEGER), Median HouseHold Income (INTEGER),
            Average Dependents (INTEGER)
            ]


5) standard_vehicle : [
    Vehicle ID (TEXT), VIN (TEXT), Make (TEXT), Model (TEXT), 
    Trim (TEXT), SubModel (TEXT), Color (TEXT), Transmission (TEXT), 
    WheelTypeID (FLOAT), WheelType (TEXT), VehYear (INTEGER), 
    VehicleAge (INTEGER), MMRAcquisitionAuctionAveragePrice (FLOAT), MMRAcquisitionAuctionCleanPrice (FLOAT), 
    MMRAcquisitionRetailAveragePrice (FLOAT), MMRAcquisitonRetailCleanPrice (FLOAT), 
    MMRCurrentAuctionAveragePrice (FLOAT), MMRCurrentAuctionCleanPrice (FLOAT), MMRCurrentRetailAveragePrice (FLOAT), 
    MMRCurrentRetailCleanPrice (FLOAT)
    ]



6) antique_vehicle : [
            Vehicle ID (TEXT),VIN (TEXT),Manufacturer (TEXT),Year (INTEGER),
            Body Style (TEXT),Make (TEXT),Model (TEXT),Options (TEXT),Description (TEXT),
            Base Original MSRP (INTEGER),Base Low Retail (INTEGER),Base Average Retail (INTEGER),
            Base High Retail (INTEGER),Car Appreciation Ratio (FLOAT),Antique Vehicle Valuation Indicator (FLOAT),
            Percentile (FLOAT),Antique Car Valuation Indicator (TEXT)
            ]


Understand the question and Always return an optimal aggregate-based query like db.base_collection.aggregate having all key value in quotes that can be executed by python, even when find appears to be a better solution.

write proper conditional values given in question. Do provide count when question asks for it

Strictly When attribute are in multiple collection strictly perform join of collections using proper common relation between collections mentioned above and verify relation.

strictly use iso conversion for datetime fields and follow proper query conventions

Strictly Follow all below points while writing aggregate query for python based execution:
- Always use "$match" condition of field type (TEXT) in aggregate query, make it not case sensitive by regex only for alphabets not for numbers (Note: use '^' or '$' for text only if exact match needed for regex) 
eg: for text "key":"$regex":"^text$","$options":"i"
for numbers"key":"Value"
- Do not write true or false in query in lower case, write in True or False format
- Queries should be as per python syntax executed by pymongo aggregate pipeline


Note: some field name may have spaces use as specified above in collection do not make up any field name
Example :
Term Effective Date should be Term Effective Date not TermEffectiveDate

As per the schema of collection provided above follow any one of below as per rule
Strictly if Match condition field type is of (TEXT) ,follow below regex like $match Example of above points only 
Example:  if Year (INTEGER) or Latitude (FLOAT) is to be Match, as it is integer and float do not follow below format

	1 - Exact Text Match of (TEXT) field: 
		{eg1}

	2 - partial Text Match of (TEXT) field: 
		{eg2}

Strictly if Match condition For (INTEGER) or (FLOAT) follow $match condition format
		{eg3}

Double check $match if used is as per above rules

Write a Robust and optimal query .Create query of only what is asked in question
Strictly Verify syntax if its correct and no error in output and all bracket are properly closed.

just output below details only
Output format:
 {op_format}

output key should have aggregation pipeline query without db.collection.aggregate

Final output should be only be output dict of aggregation and no explanation and no pre text and no additional text

verify and fix output with reference

'''
