#from dotenv import load_dotenv,find_dotenv
#load_dotenv(find_dotenv())

# from langchain import PromptTemplate,HuggingFaceHub,LLMChain
import os
# os.chdir('/home/user/app')
os.system('python -m spacy download en_core_web_sm')
from langchain_community.document_loaders import PyPDFLoader
from sklearn.metrics.pairwise import cosine_similarity
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter

from bson.objectid import ObjectId
from pymongo.mongo_client import MongoClient
import logging
import fitz
from collections import defaultdict
import datetime
import spacy
import hashlib

import uuid
from dateutil import parser

from config import *
nlp = spacy.load("en_core_web_sm")

logger = logging

dbobj = None


# all-mpnet-basev2
embeddings = HuggingFaceEmbeddings()


text_splitter = RecursiveCharacterTextSplitter(
    chunk_size = 2560,
    chunk_overlap  = 400,
)

def get_checksum(data):
    cksum = hashlib.md5(data).hexdigest()
    return cksum


def text_from_fitz_output(document):
    texts = []
    page_nums = []
    text_data = list()
    logger.debug("Retrieving data from fitz output")
    # extract each page's text,clean it and also store page number
    for num, page in enumerate(document):
        # print("page =", page)0
        page_text = page.get_text().replace("\n", "").strip()
        texts.append(page_text)
        page_nums.append(num + 1)
    for page_no, paragraph in zip(page_nums, nlp.pipe(texts)):
        sentences = [sent.text for sent in paragraph.sents]
        td = dict()
        td['page_no'] = page_no
        td['sentences'] = sentences
        text_data.append(td)
    return text_data
 
 
def get_doc_creation_date(document):
    datesub = ""
    create_date = None
    if "creationDate" in document.metadata:
        logger.debug(f"document.metadata['creationDate'] = {document.metadata['creationDate']}")
        #if document.metadata["creationDate"] == '':
        #    create_date = datetime.datetime.today().strftime('%Y-%m-%d')
        if document.metadata["creationDate"]:
            #create_date = datetime.datetime.strptime(document.metadata["creationDate"][2:14],"%Y%m%d%H%M%S").strftime("%Y-%m-%d")
            if ":" in document.metadata["creationDate"]:
                datesub = document.metadata["creationDate"].split(":")[1]
                logger.debug("date substring after split %s", datesub)
                if "-" in document.metadata["creationDate"]:
                    datesub = datesub.split("-")[0]
                    logger.debug("date substring after split %s", datesub)
                try:
                    create_date = parser.parse(datesub).strftime('%Y-%m-%d')
                except Exception as e:
                    logger.debug(f"getting date from {datesub} failed, error: {str(e)}")
            else:
                try:
                    create_date = parser.parse(document.metadata["creationDate"]).strftime('%Y-%m-%d')
                except Exception as e:
                    logger.info("Unable to parse date %s", str(e))
 
    if not create_date:
        create_date = datetime.datetime.today().strftime('%Y-%m-%d')
        logger.debug("CreationDate not present or unable to obtain from document, setting to today %s", create_date)
 
    return create_date
 
 
def extract_text_pdf(downloaded, document_name, location, checksum, chunk=30, overlap=20):
    """Module to extract and chunk texts from a given PDF
    Parameters:
        - documents: A list of paths to the PDF files whose text needs to be extracted
        - chunk: Maximum number of sentences to store in 1 single chunk
    Returns:
        The module returns a dictionary containing all the text and page numbers from the given PDFs
    """
    all_text = defaultdict(list)
    #texts = []
    #page_nums = []
    document = fitz.open("pdf", downloaded)
    if not document:
        return all_text
 
    create_date = get_doc_creation_date(document)
    logger.debug(f"document create date ={create_date}, {type(create_date)}")
 
    if not document_name:
        document_name = "no_name_" + str(uuid.uuid4())
 
    first_half = list()
    second_half = list()
    split_sentences = list()
 
    text_data = list()

    text_data = text_from_fitz_output(document)
   
    for td in text_data:
        page_no = td['page_no']
        sentences = td['sentences']

        if len(sentences) > 8:
            first_half = sentences[: len(sentences) // 2]
        else:
            first_half = sentences[:]

        logger.info(f"Analysing page {page_no}")
        logger.debug(f"Text in this page = \n{sentences}")
        if len(second_half):
            split_sentences = second_half + first_half
            logger.debug(f"first half this page = \n{first_half}")
            logger.debug(f"second half previous page = \n{second_half}")
            logger.debug(f"split_sentences = \n{split_sentences}")
 
        logger.debug(f"len of sentences = {len(sentences)}")
        logger.debug(f"len of split sentences = {len(split_sentences)}")
        for i in range(0, len(sentences), overlap):
            logger.debug(f"sentence part = {i}")
            logger.debug(". ".join(sentences[i : i + chunk]))

        if len(second_half):
            for i in range(0, len(split_sentences), overlap):
                logger.debug(f"split sentence part = {i}")
                logger.debug(". ".join(split_sentences[i : i + chunk]))
        logger.debug("-------")
 
        if len(second_half):
            all_text[document_name].extend(
                [
                    (
                        {
                            #"Content": ". ".join(split_sentences[i : i + chunk]),
                            "Content": split_sentences[i : i + chunk],
                            "metadata": {
                                "source": document_name,
                                "creation_date": create_date,
                                "page_no": page_no,
                                "paragraph_no": i,
                                "location": location,
                                "checksum": checksum
                            },
                        }
                    )
                    for i in range(0, len(split_sentences), overlap)
                ]
            )
        else:
            all_text[document_name].extend(
                [
                    (
                        {
                            # "Content": ". ".join(sentences[i : i + chunk]),
                            "Content": sentences[i: i + chunk],
                            "metadata": {
                                "source": document_name,
                                "creation_date": create_date,
                                "page_no": page_no,
                                "paragraph_no": i,
                                "location": location,
                                "checksum": checksum
                            },
                        }
                    )
                    for i in range(0, len(sentences), overlap)
                ]
            )

        if len(sentences) > 1:
            second_half = sentences[len(sentences) // 2 :]
        else:
            second_half = list()

        logger.debug(f"page = {page_no} done")
        #print(f"first half = {first_half}")
        #print(f"second half = {second_half}")
        logger.debug("------------------------------------------")
        # break
 
    extracted_text = dict(all_text)
    return extracted_text


def load_chunk_pdf(inp_path):
    print(inp_path)
    full_pdf = []
    docs_loader = PyPDFLoader(inp_path)
    all_docs = docs_loader.load_and_split()

    print('Total Pages: {}'.format(len(all_docs)))
    for docs in all_docs:
        docs_sent = docs.page_content
        texts = text_splitter.create_documents([docs_sent])
        full_pdf.extend(texts)
    
    print('Total chunks: {}'.format(len(full_pdf)))
    
    return full_pdf


def embed_doc(docs_extracted_texts):
    final_embed = list()
    for doc_elem in docs_extracted_texts:
        embedded_docs = dict()
        for doc, extracted in doc_elem.items():
            embedded_extracts = list()
            for split in extracted:
                embedded_split = dict()
                page_content = " ".join(split['Content'])
                embedded_page_content = embeddings.embed_query(page_content)
                embedded_split['Content'] = page_content
                embedded_split['Content_vector'] = embedded_page_content
                embedded_split['metadata'] = split['metadata']
                embedded_extracts.append(embedded_split)
            embedded_docs[doc] = embedded_extracts
        final_embed.append(embedded_docs)

    return final_embed

def doc_loaded(dbobj, cksum):
    found = False
    for x in cksum_coll.find({ "cksum": cksum}):
        print(x)
        found = True
    return found

def extract_text(dbobj, uploaded_docs_list):
    extracted_texts = list()
    checksums = list()
    for uploaded_doc in uploaded_docs_list:
        #document = fitz.open("pdf", uploaded_doc.getvalue())
        file_data = uploaded_doc.getvalue()
        file_name = uploaded_doc.name
        print(f"reading doc {file_name}")
        cksum = get_checksum(file_data)
        if doc_loaded(dbobj, cksum):
            print(f"{file_name} already loaded {cksum}, skipping")
            continue
        print(f"File {file_name} {cksum} not already loaded")
        extracted = extract_text_pdf(file_data, file_name, "", cksum)
        extracted_texts.append(extracted)

        print("checksum value =", {'name': file_name, 'cksum': cksum})
        checksums.append({'name': file_name, 'cksum': cksum})
    return [extracted_texts, checksums]



def load_to_db(dbobj, docs, checksums):
    for doc in docs:
        for k, v in doc.items():
            #print(f"-----------------------\nInserting {v}\n----------------------------")
            docs_coll.insert_many(v)

    for cksum in checksums:
        print(f"-----------------------\nInserting {cksum}\n----------------------------")
        cksum_coll.insert_one(cksum)


if __name__ == '__main__':
    dbobj = init_db()

    print("opening file")
    doc = 'Travel Advisory.pdf'
    fileh = open(doc, 'rb')

    print("reading file")
    doc_bytes = fileh.read()

    print("extracting text")
    [all_docs, checksums] = extract_text([doc_bytes], doc)

    print("embedding text")
    embedded_docs = embed_doc(all_docs)

    print("writing to db")
    load_to_db(dbobj, embedded_docs, checksums)