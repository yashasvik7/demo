---
title: GenYoda_main
emoji: ⚡
colorFrom: red
colorTo: pink
sdk: streamlit
sdk_version: 1.29.0
app_file: app.py
pinned: false
license: mit
python_version: 3.11
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
