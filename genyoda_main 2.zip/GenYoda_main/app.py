import sys
# sys.path.append('/home/user/app')
import os
# os.chdir('/home/user/app')
import streamlit as st
from mongo_search import mongo_find
from mongo_load import *
from mql_mongo_claude import get_db_result
import random
import time
from PIL import Image
import yaml
from yaml.loader import SafeLoader
import streamlit_authenticator as stauth
import datetime

with open('config.yaml') as file:
    config = yaml.load(file, Loader=SafeLoader)

st.set_page_config(page_title="GenYoda",layout="wide",page_icon='gen.png')

if "page" not in st.session_state:
    st.session_state.page = 'home'
    st.session_state['checksums'] = []

# dbobj = init_db()

def write_to_db(uploaded_files, checksums):
    #print(type(bytes_data))

    #if len(uploaded_files) > upload_files_limit:
    #    st.warning(f"Maximum number of files reached. Only the first {upload_files_limit} will be processed.")
    #    uploaded_files = uploaded_files[:upload_files_limit]

    [all_docs_texts, checksums] = extract_text(dbobj, uploaded_files)
    print(len(all_docs_texts))
    #print(all_docs_texts)
    print("embedding text")
    embedded_docs = embed_doc(all_docs_texts)
    #print(embedded_docs)
    print("writing to db")
    load_to_db(dbobj, embedded_docs, checksums)


def container_tabs(ses_title,chat_key):
    # Initialize chat history
    st.session_state.page = ses_title
    st.session_state.chat_key = chat_key

    st.header(ses_title)
    get_cg_logo()
    checksums = list()

    if 'checksums' not in st.session_state:
        st.session_state['checksums'] = ""

    if chat_key == 'documents':
        #uploaded_files = st.file_uploader("Choose a file", accept_multiple_files=True, type='pdf')
        
        with st.form("my-form", clear_on_submit=True):
        #file = st.file_uploader("FILE UPLOADER")
            uploaded_files = st.file_uploader("Choose a file", accept_multiple_files=True, type='pdf')
            submitted = st.form_submit_button("UPLOAD!")

            if len(uploaded_files) > upload_files_limit:
                st.warning(f"Maximum number of files reached. Only the first {upload_files_limit} will be processed.")
                uploaded_files = uploaded_files[:upload_files_limit]

            upload_files_name = list()
            new_uploaded_files = list()
            for uploaded_doc in uploaded_files:
                #document = fitz.open("pdf", uploaded_doc.getvalue())-
                file_data = uploaded_doc.getvalue()
                file_name = uploaded_doc.name
                print(f"getting checksum for {file_name}")
                cksum = get_checksum(file_data)
                if doc_loaded(dbobj, cksum):
                    print(f"{file_name} {cksum} already loaded, skipping")
                    checksums.append({'name': file_name, 'cksum': cksum})
                    st.session_state['checksums'].extend(checksums)
                    st.write(f"{', '.join(upload_files_name)} already UPLOADED!")
                    continue
                new_uploaded_files.append(uploaded_doc)
                upload_files_name.append(file_name)
                checksums.append({'name': file_name, 'cksum': cksum})
                st.session_state['checksums'].extend(checksums)

            uploaded_files = None


            if submitted and new_uploaded_files is not None and len(new_uploaded_files):
                with st.spinner("Uploading.."):
                    write_to_db(new_uploaded_files, checksums)
                    st.write(f"{', '.join(upload_files_name)} UPLOADED!")

    if "messages" not in st.session_state:
        st.session_state.messages = {chat_key:[]}
        st.session_state.messages[chat_key].append({"role": "assistant", "content": "GenYoda : Hello 👋, I am your chat assistant which will help you to search over {}".format(chat_key),"avatar":'🧊'})
    elif chat_key not in st.session_state.messages:
        st.session_state.messages[chat_key] = []
        st.session_state.messages[chat_key].append({"role": "assistant","content": "GenYoda : Hello 👋, I am your chat assistant which will help you to search over {}".format(chat_key),"avatar":'🧊'})

    # Display chat messages from history on app rerun
    for message in st.session_state.messages[chat_key]:
        with st.chat_message(message["role"],avatar=message.get("avatar",None)):
            st.markdown(message["content"])

    # Accept user input
    if chat_key == 'documents' and len(st.session_state['checksums']) > 0:
        col1, col2 = st.columns([1,2])
        with col1:
            agree = st.checkbox('Search only within these files :')
        with col2:
            with st.expander("Files"):
                unique_files = []
                for file_n in st.session_state['checksums']:
                    if file_n['name'] not in unique_files:
                        st.write(file_n['name'])
                        unique_files.append(file_n['name'])
        # agree = st.checkbox('Search only within these files')
    else:
        agree = False

    if prompt := st.chat_input("What's up?"):
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(prompt)
        # Add user message to chat history
        st.session_state.messages[chat_key].append({"role": "user", "content": prompt})

        response = f"GenYoda: {prompt}"
        # Display assistant response in chat message container
        cksums = list()
        with st.chat_message("assistant",avatar='🧊'):
            with st.spinner("Thinking.."):
                # time.sleep(2)
                checksums = st.session_state['checksums']
                print(f"checksums from the session state ={checksums}")
                #st.session_state['checksums'] = ""
                if chat_key == 'documents':
                    if agree:
                        print(f"checksums ={checksums}")
                        for c in checksums:
                            cksums.append(c['cksum'])
                        print(f"searching only within {cksums}")
                        st.write('Search will be only within the documents uploaded')
                    else:
                        st.write('Search will be within all the documents uploaded so far')

                    result = mongo_find(prompt, cksums)
                else:
                    result = get_db_result(prompt)
                # result = "ssd"
                st.markdown("GenYoda : " + result)
        # Add assistant response to chat history
        st.session_state.messages[chat_key].append({"role": "assistant", "content": "GenYoda : " + result,"avatar":'🧊'})


def reset_chat():
    st.session_state.messages = {}


def home():
    #st.snow()
    get_cg_logo("Welcome..")
    st.header("Chat with Your Optimal Digital Assistant")
    st.markdown("Please Select 'Search Document' or 'Search Database' option from left to proceed")


def header(content):
    st.markdown(f'<p style="background-color:#0066cc;color:#33ff33;font-size:24px;border-radius:2%;">{content}</p>',
                unsafe_allow_html=True)

def get_cg_logo(dis_text=None):
    # from PIL import Image

    title_container = st.container()
    image_container =st.container()
    col1, col2 = st.columns([10, 1])
    image = Image.open('Capgemini.png')
    st.markdown(
        """
    <style>
        button[data-testid="StyledFullScreenButton"]{
        visibility: hidden;}
        div[data-testid="column"] div:has(div.fixed-header) {
            position: fixed;
            top: 2.875rem;
            z-index: 999;
        }
    </style>
        """,
        unsafe_allow_html=True
    )

    with title_container:
        with col2:
            st.image(image, width=64)
            st.write("""<div class='fixed-header'/>""", unsafe_allow_html=True)
    with image_container:
        if dis_text is not None:
            with col1:
                st.markdown(f'<h1 style="color: purple">{dis_text}</h1>',
                            unsafe_allow_html=True)
            # st.write("""<div class='fixed-header'/>""", unsafe_allow_html=True)
            # stMarkdownContainer

# header("Customer First Chat")

with st.sidebar:
    print("inside sidebar")
    header_t = st.container()
    header_t.image('gen.png', width=200)
    header_t.write("""<div class='fixed-header'/>""", unsafe_allow_html=True)

    ### Custom CSS for the sticky header
    st.markdown(
        """
    <style>
        div[data-testid="stVerticalBlock"] div:has(div.fixed-header) {
            position: static;
            top: 2.875rem;
            z-index: 999;
        }
    </style>
        """,
        unsafe_allow_html=True
    )
    # st.title("GenYoda")

    authenticator = stauth.Authenticate(
        config['credentials'],
        config['cookie']['name'],
        config['cookie']['key'],
        config['cookie']['expiry_days']
    )

    authenticator.login('Login', 'sidebar')

    if st.session_state["authentication_status"]:
        home_button = st.button("Home")
        db_button = st.button("Ask Database")
        doc_button = st.button("Ask Documents")
        reset_chat_button = st.button("Reset Chat")
        authenticator.logout('Logout', 'sidebar', key='auth')
    else:
        home_button,db_button,doc_button,reset_chat_button = False, False , False, False

    # st.write(f'Welcome *{st.session_state["name"]}*')
    if st.session_state["authentication_status"] is False:
        st.error('Username/password is incorrect')
    elif st.session_state["authentication_status"] is None:
        st.warning('Please enter your username and password')

# if st.session_state["authentication_status"]:
if reset_chat_button:
    st.header("Chat has been Reset")
    reset_chat()
elif doc_button:
    container_tabs("Ask Documents",'documents')
elif db_button:
    print("called db")
    container_tabs("Ask Database",'database')
elif st.session_state.page == 'home' or home_button or st.session_state["authentication_status"] is None:
    home()
else:
    print("inside else")
    container_tabs(st.session_state.page,st.session_state.chat_key)
# else:
#     home()
