from pymongo.mongo_client import MongoClient
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv
load_dotenv()


api_app_key = os.getenv("API_KEY")

embeddings = HuggingFaceEmbeddings()

mongo_uri = "mongodb+srv://Rahul:YoAbz5j9hN4l0A0f@cluster0.80157cr.mongodb.net/?retryWrites=true&w=majority"
#mongo_uri = "mongodb+srv://capgemini:capgemini@atlascluster.eihlgpc.mongodb.net/?retryWrites=true&w=majority"

mongo_db_name = 'metlife'
mongo_docs_collection = 'documents'
mongo_docs_cksum = 'checksums'
mongo_index_name = 'metlife_search_vec'
summary_coll_name = "summary_complete_docs"
bread_data_coll = 'bread_data'
bread_data_vector = 'bread_data_vector'
bread_data_cksum = "bread_checksums"

upload_files_limit = 2

dbobj = None
docs_coll  = None
cksum_coll = None
bread_cksum_coll = None
summary_coll = None
bread_coll = None

def init_llm(model_nm):
    if model_nm == 'gpt35':
        llm = AzureChatOpenAI(
            deployment_name="genyoda35",
            model_name="gpt-35-turbo",
            openai_api_key='0e1c91cf40fc4432a9da9d3d4b493dc4',
            openai_api_version='2023-07-01-preview',
            # openai_api_base='https://genai-cube.openai.azure.com/',
            azure_endpoint='https://genai-cube.openai.azure.com/',
            temperature=0.01,
            max_tokens=4000
        )

        return llm



def init_db():
    # from pymongo.server_api import ServerApi
    # Create a new client and connect to the server
    uri = mongo_uri
    client = MongoClient(uri)
    # Send a ping to confirm a successful connection
    try:
        client.admin.command('ping')
        print("Pinged your deployment. You successfully connected to MongoDB!")
    except Exception as e:
        print(e)

    global dbobj
    global docs_coll
    global cksum_coll
    global summary_coll
    global bread_coll
    global bread_cksum_coll

    dbobj = client[mongo_db_name]
    docs_coll  = dbobj[mongo_docs_collection]
    cksum_coll = dbobj[mongo_docs_cksum]
    summary_coll = dbobj[summary_coll_name]
    bread_coll = dbobj[bread_data_coll]
    bread_cksum_coll = dbobj[bread_data_cksum]
    #return

init_db()