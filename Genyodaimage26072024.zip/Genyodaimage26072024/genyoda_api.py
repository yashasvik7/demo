from fastapi import FastAPI,UploadFile,File,Request,Depends
from typing import Union, List
from pydantic import Json
import uvicorn
from genyoda_main_mongo import get_answer, local_pdf_paths
from io import BytesIO
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import json
from mongo_load import ingest_bread_op, write_to_db
from pydantic import BaseModel, model_validator
from fastapi.responses import JSONResponse
from config import *
from fastapi.security.api_key import APIKey
import auth
import os
from langchain_community.document_loaders import PyPDFLoader

if os.name != 'nt':
    from langchain_community.document_loaders.pebblo import PebbloSafeLoader
else:
    PebbloSafeLoader = None  # Or handle the alternative if needed


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class item_values(BaseModel):
    filename :List[str]
    checksum: List[str]


class item_keys(BaseModel):
    product : item_values
    bread : item_values

    @model_validator(mode='before')
    @classmethod
    def validate_to_json(cls, value):
        if isinstance(value, str):
            return cls(**json.loads(value))
        return value


class Item(BaseModel):
    prompt: str
    checksum: Union[item_keys, None] = None

@app.get("/")
async def root():
    return {"message": "Welcome to Genyoda"}


@app.exception_handler(Exception)
async def validation_exception_handler(request: Request, exc: Exception):
    # Change here to Logger
    return JSONResponse(
        status_code=500,
        content={
            "message": (
                f" Exception message is {exc.args[0]}."
            )
        },
    )


# f"Failed method {request.method} at URL {request.url}."
# f" Exception message is {exc!r}."

@app.post("/upload")
async def upload_files(api_key: APIKey = Depends(auth.get_api_key),bread: List[UploadFile] = File(...),prod: List[UploadFile] = File(...),glossary: Union[UploadFile, None] = None, checksum: Union[item_keys,None]=None):
    response = dict()

    if checksum is not None:
        checksum = checksum.dict()

    temp_prod_res = checksum['product'] if checksum is not None else checksum
    temp_prod_bread = checksum['bread'] if checksum is not None else checksum

    for prod_files in prod:
        prod_in_bytes = prod_files.file.read()
        prod_inp=BytesIO(prod_in_bytes)
        temp_prod_res = write_to_db([prod_inp], prod_files.filename, temp_prod_res)

    for bread_files in bread:
        temp_prod_bread = ingest_bread_op(bread_files, temp_prod_bread)


    response['product'] = temp_prod_res
    response['bread'] = temp_prod_bread

    return json.dumps(response)


@app.post("/query")
async def query_genyoda(item: Item, api_key: APIKey = Depends(auth.get_api_key)):
    item = item.dict()
    prompt, checksum = item['prompt'], item['checksum']

    # Call the get_answer function
    output = get_answer(prompt, checksum, local_pdf_paths)  # Provide the correct pdf_paths if needed

    response = {
        'prompt': prompt,
        'result': output
    }

    return response


# def generate_html_table(data):
#     keys = set()
#     for section in data.values():
#         for item in section:
#             keys.update(item.keys())

#     html_content = """
#     <html>
#         <body>
#             <table border="1">
#                 <tr>
#                     <th>Type</th>"""
    
#     for key in keys:
#         html_content += f"<th>{key.capitalize()}</th>"
#     html_content += "</tr>"

#     max_rows = max(len(data['aligned_logic']), len(data['deviated_logic']))

#     for i in range(max_rows):
#         aligned_row = data['aligned_logic'][i] if i < len(data['aligned_logic']) else {}
#         deviated_row = data['deviated_logic'][i] if i < len(data['deviated_logic']) else {}

#         # Add aligned logic row
#         html_content += "<tr><td>Aligned Logic</td>"
#         for key in keys:
#             html_content += f"<td>{aligned_row.get(key, '')}</td>"
#         html_content += "</tr>"

#         # Add deviated logic row
#         html_content += "<tr><td>Deviated Logic</td>"
#         for key in keys:
#             html_content += f"<td>{deviated_row.get(key, '')}</td>"
#         html_content += "</tr>"

#     html_content += """
#             </table>
#         </body>
#     </html>
#     """
    
#     return html_content

# @app.post("/query", response_class=HTMLResponse)
# async def query_genyoda(item: Item, api_key: APIKey = Depends(auth.get_api_key)):
#     item = item.dict()
#     prompt, checksum = item['prompt'], item['checksum']

#     response = get_answer(prompt, checksum)

#     html_content = generate_html_table(response)

#     return HTMLResponse(content=html_content)


if __name__ == "__main__":
    uvicorn.run("genyoda_api:app", host="127.0.0.1", port=5000, log_level="info")
