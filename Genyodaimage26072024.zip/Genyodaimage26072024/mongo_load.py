#from dotenv import load_dotenv,find_dotenv
#load_dotenv(find_dotenv())

# from langchain import PromptTemplate,HuggingFaceHub,LLMChain
import os
# os.chdir('/home/user/app')
# os.system('python -m spacy download en_core_web_sm')
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

from text_table_extract import get_text_tables
import logging
import fitz
from collections import defaultdict
import datetime
import spacy
import hashlib
import pandas as pd

import uuid
from dateutil import parser

from config import *
nlp = spacy.load("en_core_web_sm")

logger = logging

dbobj = None


# all-mpnet-basev2



text_splitter = RecursiveCharacterTextSplitter(
    chunk_size = 2560,
    chunk_overlap  = 400,
)

def get_checksum(data):
    cksum = hashlib.md5(data).hexdigest()
    return cksum


def text_from_fitz_output(document):
    # texts = []
    page_nums = []
    text_data = list()
    table_data = list()
    logger.debug("Retrieving data from fitz output")

    tables_d,texts = get_text_tables(document)

    for page_no, paragraph in texts.items():
        for nlp_sent in nlp.pipe(paragraph):
            sentences = [sent.text for sent in nlp_sent.sents]
            td = dict()
            td['page_no'] = page_no + 1
            td['sentences'] = sentences
            text_data.append(td)

    for pg_num, tab_data in tables_d.items():
        for tab in tab_data:
            for tabs in tab['table']:
                td = dict()
                td['page_no'] = pg_num
                # td['preamble'] = tab['preamble']
                td['table'] = tab['preamble'] + '\n' + tabs.to_markdown(index=False)
                table_data.append(td)

    return text_data,table_data 
 
def get_doc_creation_date(document):
    datesub = ""
    create_date = None
    if "creationDate" in document.metadata:
        logger.debug(f"document.metadata['creationDate'] = {document.metadata['creationDate']}")
        #if document.metadata["creationDate"] == '':
        #    create_date = datetime.datetime.today().strftime('%Y-%m-%d')
        if document.metadata["creationDate"]:
            #create_date = datetime.datetime.strptime(document.metadata["creationDate"][2:14],"%Y%m%d%H%M%S").strftime("%Y-%m-%d")
            if ":" in document.metadata["creationDate"]:
                datesub = document.metadata["creationDate"].split(":")[1]
                logger.debug("date substring after split %s", datesub)
                if "-" in document.metadata["creationDate"]:
                    datesub = datesub.split("-")[0]
                    logger.debug("date substring after split %s", datesub)
                try:
                    create_date = parser.parse(datesub).strftime('%Y-%m-%d')
                except Exception as e:
                    logger.debug(f"getting date from {datesub} failed, error: {str(e)}")
            else:
                try:
                    create_date = parser.parse(document.metadata["creationDate"]).strftime('%Y-%m-%d')
                except Exception as e:
                    logger.info("Unable to parse date %s", str(e))
 
    if not create_date:
        create_date = datetime.datetime.today().strftime('%Y-%m-%d')
        logger.debug("CreationDate not present or unable to obtain from document, setting to today %s", create_date)
 
    return create_date
 
 
def extract_text_pdf(downloaded, document_name, location, checksum, chunk=30, overlap=20):
    """Module to extract and chunk texts from a given PDF
    Parameters:
        - documents: A list of paths to the PDF files whose text needs to be extracted
        - chunk: Maximum number of sentences to store in 1 single chunk
    Returns:
        The module returns a dictionary containing all the text and page numbers from the given PDFs
    """
    all_text = defaultdict(list)
    #texts = []
    #page_nums = []
    # document = fitz.open("pdf", downloaded)
    document = downloaded
    if not document:
        return all_text
 
    create_date = get_doc_creation_date(document)
    logger.debug(f"document create date ={create_date}, {type(create_date)}")
 
    if not document_name:
        document_name = "no_name_" + str(uuid.uuid4())
 
    first_half = list()
    second_half = list()
    split_sentences = list()
 
    text_data = list()

    text_data,tables_data = text_from_fitz_output(document)
   
    for td in text_data:
        page_no = td['page_no']
        sentences = td['sentences']

        if len(sentences) > 8:
            first_half = sentences[: len(sentences) // 2]
        else:
            first_half = sentences[:]

        logger.info(f"Analysing page {page_no}")
        logger.debug(f"Text in this page = \n{sentences}")
        if len(second_half):
            split_sentences = second_half + first_half
            logger.debug(f"first half this page = \n{first_half}")
            logger.debug(f"second half previous page = \n{second_half}")
            logger.debug(f"split_sentences = \n{split_sentences}")
 
        logger.debug(f"len of sentences = {len(sentences)}")
        logger.debug(f"len of split sentences = {len(split_sentences)}")
        for i in range(0, len(sentences), overlap):
            logger.debug(f"sentence part = {i}")
            logger.debug(". ".join(sentences[i : i + chunk]))

        if len(second_half):
            for i in range(0, len(split_sentences), overlap):
                logger.debug(f"split sentence part = {i}")
                logger.debug(". ".join(split_sentences[i : i + chunk]))
        logger.debug("-------")
 
        if len(second_half):
            all_text[document_name].extend(
                [
                    (
                        {
                            #"Content": ". ".join(split_sentences[i : i + chunk]),
                            "Content": split_sentences[i : i + chunk],
                            "metadata": {
                                "source": document_name,
                                "creation_date": create_date,
                                "page_no": page_no,
                                "paragraph_no": i,
                                "location": location,
                                "checksum": checksum
                            },
                        }
                    )
                    for i in range(0, len(split_sentences), overlap)
                ]
            )
        else:
            all_text[document_name].extend(
                [
                    (
                        {
                            # "Content": ". ".join(sentences[i : i + chunk]),
                            "Content": sentences[i: i + chunk],
                            "metadata": {
                                "source": document_name,
                                "creation_date": create_date,
                                "page_no": page_no,
                                "paragraph_no": i,
                                "location": location,
                                "checksum": checksum
                            },
                        }
                    )
                    for i in range(0, len(sentences), overlap)
                ]
            )

        if len(sentences) > 1:
            second_half = sentences[len(sentences) // 2 :]
        else:
            second_half = list()

        logger.debug(f"page = {page_no} done")
        #print(f"first half = {first_half}")
        #print(f"second half = {second_half}")
        logger.debug("------------------------------------------")
        # break

    for tab_data in tables_data:
        all_text[document_name].append(
                (
                    {
                        # "Content": ". ".join(split_sentences[i : i + chunk]),
                        "Content": [tab_data['table']],
                        "metadata": {
                            "source": document_name,
                            "creation_date": create_date,
                            "page_no": tab_data['page_no'],
                            "paragraph_no": '',
                            "location": location,
                            "checksum": checksum
                        },
                    }
                )
        )

    extracted_text = dict(all_text)
    return extracted_text


def load_chunk_pdf(inp_path):
    print(inp_path)
    full_pdf = []
    docs_loader = PyPDFLoader(inp_path)
    all_docs = docs_loader.load_and_split()

    print('Total Pages: {}'.format(len(all_docs)))
    for docs in all_docs:
        docs_sent = docs.page_content
        texts = text_splitter.create_documents([docs_sent])
        full_pdf.extend(texts)
    
    print('Total chunks: {}'.format(len(full_pdf)))
    
    return full_pdf


def embed_doc(docs_extracted_texts):
    final_embed = list()
    for doc_elem in docs_extracted_texts:
        embedded_docs = dict()
        for doc, extracted in doc_elem.items():
            embedded_extracts = list()
            for split in extracted:
                embedded_split = dict()
                page_content = " ".join(split['Content'])
                embedded_page_content = embeddings.embed_query(page_content)
                embedded_split['Content'] = page_content
                embedded_split['Content_vector'] = embedded_page_content
                embedded_split['metadata'] = split['metadata']
                embedded_extracts.append(embedded_split)
            embedded_docs[doc] = embedded_extracts
        final_embed.append(embedded_docs)

    return final_embed

def doc_loaded(coll_name, cksum):
    found = False
    for x in coll_name.find({ "cksum": cksum}):
        print(x)
        found = True
    return found

def ingest_bread_op(b_data, old_cksum):
    if old_cksum is None:
        response = {
            "filename" : [b_data.filename],
            "checksum": [],
        }
    else:
        response = old_cksum
    try:
        raw_inp_data = pd.read_excel(b_data.file, sheet_name='Documentation', engine='openpyxl')
    except ValueError as ve:
        raise Exception(f"For File '{b_data.filename}' : {ve}")
    except Exception as e:
        raise Exception(f"File '{b_data.filename}' Failed with error : {e}")
        # raise Exception(f"Sheet Name : Documentation missing in Excel (File Name : {b_data.filename})")

    raw_inp_data.columns = [i.strip() for i in raw_inp_data.columns]

    filtered_cols = ['Chunk Name', 'Code snippet', 'Detailed Documentation', 'Short Summary']
    try:
        inp_data = raw_inp_data[filtered_cols].to_dict(orient="records")
    except KeyError:
        raise Exception(f"Column Header Missing in Excel for File {b_data.filename} : Following columns should be present ('Chunk Name', 'Code snippet', 'Detailed Documentation', 'Short Summary')")
    except Exception as e:
        raise Exception(f"File '{b_data.filename}' Failed with error : {e}")

    data_cksum = get_checksum(data=str(inp_data).encode("utf-8"))

    if doc_loaded(bread_cksum_coll, data_cksum):
        print(f"{b_data.filename} already loaded {data_cksum}, skipping")
    else:
        for record in inp_data:
            record['Documentation_embedding'] = embeddings.embed_query(record['Detailed Documentation'])
            record['checksum'] = data_cksum
        
        # print(inp_data)
        cksm_insert_op = bread_cksum_coll.insert_one({'name': b_data.filename, 'cksum': data_cksum})
        bread_insert_op = bread_coll.insert_many(inp_data)

    response['filename'].append(b_data.filename)
    response['filename'] = list(set(response['filename']))
    response['checksum'].append(data_cksum)
    response['checksum'] = list(set(response['checksum']))

    return response



def extract_text(dbobj, uploaded_docs_list,filename,old_cksum):
    extracted_texts = list()
    checksums = list()
    if old_cksum is None:
        all_checksum = {
                "filename" : [],
                "checksum": [],
            }
    else:
        all_checksum = old_cksum

    for uploaded_doc in uploaded_docs_list:
        #document = fitz.open("pdf", uploaded_doc.getvalue())
        # file_data = uploaded_doc.getvalue()
        # file_name = uploaded_doc.name
        # file_data = fitz.open("pdf", uploaded_doc)
        file_data = fitz.open(stream=uploaded_doc)
        chksum_text = ''.join([file_data[pg_num].get_text() for pg_num in range(0,file_data.page_count)]).encode("utf-8")
        # file_data = uploaded_doc
        file_name = filename

        print(f"reading doc {file_name}")
        cksum = get_checksum(chksum_text)
        all_checksum['filename'].append(file_name)
        all_checksum['checksum'].append(cksum)
        
        if doc_loaded(cksum_coll, cksum):
            print(f"{file_name} already loaded {cksum}, skipping")
            continue
        print(f"File {file_name} {cksum} not already loaded")
        print(uploaded_doc)
        extracted = extract_text_pdf(file_data, file_name, "", cksum)
        extracted_texts.append(extracted)

        print("checksum value =", {'name': file_name, 'cksum': cksum})
        checksums.append({'name': file_name, 'cksum': cksum})

    all_checksum['filename'] = list(set(all_checksum['filename']))
    all_checksum['checksum'] = list(set(all_checksum['checksum']))

    return [extracted_texts, checksums,all_checksum]

def load_to_db(dbobj, docs, checksums):
    for doc in docs:
        for k, v in doc.items():
            #print(f"-----------------------\nInserting {v}\n----------------------------")
            docs_coll.insert_many(v)

    for cksum in checksums:
        print(f"-----------------------\nInserting {cksum}\n----------------------------")
        cksum_coll.insert_one(cksum)


def write_to_db(uploaded_files, filename, old_cksum):

    [all_docs_texts, checksums,all_checksum] = extract_text(dbobj, uploaded_files, filename, old_cksum)
    print(all_docs_texts)
    print(len(all_docs_texts))
    #print(all_docs_texts)
    print("embedding text")
    embedded_docs = embed_doc(all_docs_texts)
    #print(embedded_docs)
    print("writing to db")
    if filename not in ['1605 - Whole Life Policy_Custom Life.pdf','CUSTOMLIFE_Producer Guide and Formulas.pdf']:
        load_to_db(dbobj, embedded_docs, checksums)
        # pass
    else:
        if filename == '1605 - Whole Life Policy_Custom Life.pdf':
            all_checksum['checksum'].append('92093adbefd67452792e46aab07955ef')
        elif filename == 'CUSTOMLIFE_Producer Guide and Formulas.pdf':
            all_checksum['checksum'].append('ac9877315ead6590b809108d4ad74d91')
        print("not loaded")
    return all_checksum


if __name__ == '__main__':
    import glob
    
    files_lst = glob.glob(r'./pdf/*')
    # doc = r'C:\Users\rahgoel\PycharmProjects\FHIR\genyoda_api\inp_files\Single Premium WL.pdf'
    for doc in files_lst[0:]:
        fileh = open(doc, 'rb')
    
        print("reading file")
        doc_bytes = fileh.read()
    
        write_to_db([doc_bytes])

    # dbobj = init_db()

    # print("opening file")
    # doc = 'Travel Advisory.pdf'
    # fileh = open(doc, 'rb')

    # print("reading file")
    # doc_bytes = fileh.read()

    # print("extracting text")
    # [all_docs, checksums] = extract_text([doc_bytes], doc)

    # print("embedding text")
    # embedded_docs = embed_doc(all_docs)

    # print("writing to db")
    # load_to_db(dbobj, embedded_docs, checksums)
