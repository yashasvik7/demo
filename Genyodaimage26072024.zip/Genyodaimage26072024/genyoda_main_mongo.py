import os
import re
import io
import fitz
import pymongo
from PIL import Image, ImageDraw
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.docstore.document import Document
from langchain_community.callbacks import get_openai_callback
from prompts import map_template, comb_template, prompt_consolidate
from config import *

os.environ['CURL_CA_BUNDLE'] = ''

# MongoDB configuration
mongo_uri = "mongodb+srv://Rahul:YoAbz5j9hN4l0A0f@cluster0.80157cr.mongodb.net/?retryWrites=true&w=majority"
mongo_db_name = 'metlife'
mongo_docs_collection = 'documents'
mongo_docs_cksum = 'checksums'
mongo_index_name = 'metlife_search_vec'
summary_coll_name = "summary_complete_docs"
bread_data_coll = 'bread_data'
bread_data_vector = 'bread_data_vector'
bread_data_cksum = "bread_checksums"

client = pymongo.MongoClient(mongo_uri)
db = client[mongo_db_name]
docs_coll = db[mongo_docs_collection]

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=2048,
    chunk_overlap=500,
)

local_pdf_paths = {
    'CUSTOMLIFE_Producer Guide and Formulas.pdf': r'C:\Users\YKONDABO\Downloads\Dump\GenYoda\genyodareviewcode\CUSTOMLIFE_Producer Guide and Formulas.pdf'
}

def extract_page_screenshot(pdf_path, page_number, dpi=150):
    document = fitz.open(pdf_path)
    if page_number < 0 or page_number >= len(document):
        raise ValueError(f"Page number {page_number} is out of range.")
    page = document.load_page(page_number)
    pix = page.get_pixmap(dpi=dpi)
    img_data = pix.tobytes()
    image = Image.open(io.BytesIO(img_data))
    return image


def highlight_bbox_on_image(image, bbox, color=(255, 0, 0), thickness=2):
    # bbox = (x_min, y_min, x_max, y_max)
    draw = ImageDraw.Draw(image)
    draw.rectangle(bbox, outline=color, width=thickness)
    return image

def get_text_split_bread(question_txt, checksums):
    encoded_query = embeddings.embed_query(question_txt)
    vector_query = {
        "queryVector": encoded_query,
        "path": "Documentation_embedding",
        "numCandidates": 150,
        "limit": 15,
        "index": bread_data_vector,
    }

    if checksums:
        query_filter = {"checksum": {"$in": checksums}}
        vector_query['filter'] = query_filter

    pipeline = [
        {"$vectorSearch": vector_query},
        {"$set": {"score": {"$meta": "vectorSearchScore"}}},
        {'$unset': ['Documentation_embedding', '_id']}, {'$limit': 4}
    ]

    results = list(db[bread_data_coll].aggregate(pipeline))

    contexts = '\n'
    for res in results:
        this_content = f"""
{res['Detailed Documentation'].strip()}
Chunk Name :- {res['Chunk Name']}
"""
        contexts += this_content + '-'*15 + '\n'

    return contexts

def get_text_split(question_txt, checksums):
    encoded_query = embeddings.embed_query(question_txt)

    vector_query = {
        "queryVector": encoded_query,
        "path": "Content_vector",
        "numCandidates": 150,
        "limit": 15,
        "index": mongo_index_name,
    }

    if checksums:
        query_filter = {"metadata.checksum": {"$in": checksums}}
        vector_query['filter'] = query_filter

    pipeline = [
        {"$vectorSearch": vector_query},
        {"$set": {"score": {"$meta": "vectorSearchScore"}}},
        {'$unset': ['Content_vector', '_id']}, {'$limit': 5}
    ]

    results = list(docs_coll.aggregate(pipeline))

    contexts = '\n'

    for res in results:
        metadata = res['metadata']
        pg_no = metadata.get('page_no', None)
        file_nm = metadata.get('source', None)
        creation_dt = metadata.get('creation_date', None)

        for info_inp in [file_nm, pg_no, creation_dt]:
            if info_inp is not None:
                contexts += str(info_inp) + ', '
            else:
                contexts += 'NA' + ', '

        contexts = contexts[:-2] + ' : ' + res['Content'] + "\n\n"

    doc_context = [Document(page_content=contexts)]
    return contexts

def get_text_excel(file_path, sheet_name=0):
    ex_data = pd.read_excel(file_path, sheet_name=sheet_name)
    return ex_data

def get_summary(doc_inp, assistant_for, instuct, question):
    map_prompt = PromptTemplate(template=map_template, input_variables=["text"],
                                partial_variables={"type": assistant_for, "instructions": instuct, "question": question})

    chain = LLMChain(prompt=map_prompt, llm=llm)
    sum_chain = chain.run(doc_inp)
    print("Summary Chain - ", sum_chain)
    return sum_chain

def get_consolidated_summary(summary1, summary2, gloss, question):
    cons_prompt = PromptTemplate(template=prompt_consolidate, input_variables=['question'],
                                 partial_variables={"summary_1": summary1, "summary_2": summary2, "glossary": gloss})

    llm_chain = LLMChain(prompt=cons_prompt, llm=llm)
    resp = llm_chain.run(question)
    return resp

def get_doc_format(raw_data):
    final_list = []
    for i in raw_data:
        final_list.append(Document(page_content=str(i[0]), metadata={"source": i[1]}))
    return final_list

llm = init_llm('gpt35')

bread_data_instuct = '''
Summary must be as per the flow of code or program and logical conditions if any, have details and mentioning of column or tool or table it is making use of in each flow.
Mention The logical conditions with its values in summary if you find any.
'''

product_data_instuct = '''
Provide detailed Summary, with all details covered in detail along with all conditional values with any charges or numerical value or tenure
'''

def fetch_pdf_from_mongodb(pdf_name, checksum):
    # Search for the document by checksum
    document = docs_coll.find_one({"cksum": checksum})
    if document:
        pdf_data = document.get('filedata')
        if pdf_data:
            pdf_path = f'/tmp/{pdf_name}'
            with open(pdf_path, 'wb') as f:
                f.write(pdf_data)
            return pdf_path
    return None

def extract_page_numbers_from_output(output):
    """
    Extract page numbers from the output text based on the given format.
    """
    # Extract all occurrences of "Page <number>"
    page_numbers = re.findall(r"Page (\d+)", output)
    return [int(page) for page in page_numbers]



def get_answer(query_ques, checksum_inp, pdf_paths):
    with get_openai_callback() as cb:
        product_data = ""
        bread_data = ""

        if checksum_inp:
            if checksum_inp.get('product') and checksum_inp['product'].get('checksum'):
                product_data = get_text_split(query_ques, checksum_inp['product']['checksum'])
            if checksum_inp.get('bread') and checksum_inp['bread'].get('checksum'):
                bread_data = get_text_split_bread(query_ques, checksum_inp['bread']['checksum'])
        else:
            product_data = get_text_split(query_ques, [])
            bread_data = get_text_split_bread(query_ques, [])

        summary_2 = get_summary(product_data, 'Insurance Product', product_data_instuct, query_ques)
        consolidated_summary = get_consolidated_summary(bread_data, summary_2, '', query_ques)

        # Extract page numbers from the consolidated summary
        page_numbers = extract_page_numbers_from_output(consolidated_summary)

        # Generate screenshots for the extracted page numbers
        if pdf_paths:
            for pdf_name, pdf_path in pdf_paths.items():
                for page_number in page_numbers:
                    try:
                        # fitz uses zero-based page numbering
                        zero_based_page_number = page_number
                        image = extract_page_screenshot(pdf_path, zero_based_page_number)  
                        if image:
                            output_dir = 'screenshots'
                            os.makedirs(output_dir, exist_ok=True)
                            image_filename = os.path.join(output_dir, f"{os.path.splitext(os.path.basename(pdf_name))[0]}_Page_{page_number}.png")
                            image.save(image_filename)
                            print(f"Screenshot saved as {image_filename}")
                    except Exception as e:
                        print(f"Error generating screenshot for {pdf_name} page {page_number}: {e}")

        print(cb)

    return consolidated_summary



query_ques = "Is the one-year term insurance portion of the additional protection coverage convertible?"
checksum_inp = None  # Populate as necessary

result = get_answer(query_ques, checksum_inp, local_pdf_paths)
print(result)
