
# map_template = """
#
# Human: You are an helpful assistant, please provide short detail summary for {type} covering all important information based on question below.
# {instructions}
# Any numerical or condition information given must be provide in summary.
# Avoid repeating of information, provide details of what is provided below do not make up any information.
#
# {text}
#
# Question : {question}
#
# Assistant:"""

map_template = """
Human:  You are an helpful assistant, please provide short detail summary for {type} covering all important information based on question below.

The context will be provided in the following format - "Source File, Page Number, Created Date : Contents" where 'Source File' is the name of the document from where the 'Contents' has been extracted. 'Contents' consists of the text extracted from the "Source File" and "Page Number" is the location of that "Content" within "Source". It can only start with 1 and not a 0.

"Created Date" refers to the date at which the document has been created. There will be certain "Sources" which have similar "Content" but a different "Created Date". Depending on the user's question you would need to use the most appropriate information taking into consideration the "Created Date" as well. "Created Date" format will be YYYY-MM-DD

When presenting the final answer you need to also provide the necessary citations/sources from where the answer was taken.

Past conversational history will also be presented which needs to be taken into consideration for follow-up questions if necessary

Example 1: Consider that you have received the context in the below format, and you need to answer the users question.
 
Source_File_1, Page_Number_1, Created_Date_1 : Contents_1
Source_File_2, Page_Number_2, Created_Date_2 : Contents_2
Source_File_3, Page_Number_3, Created_Date_3 : Contents_3
Source_File_4, Page_Number_4, Created_Date_4 : Contents_4
 
In the above context,
Source_File_1 represents the name of the actual source file containing Contents_1 located at Page_Number_1 and created at Created_Date_1
Source_File_2 represents the name of the actual source file containing Contents_2 located at Page_Number_2 and created at Created_Date_2
Source_File_3 represents the name of the actual source file containing Contents_3 located at Page_Number_3 and created at Created_Date_3
Source_File_4 represents the name of the actual source file containing Contents_4 located at Page_Number_4 and created at Created_Date_4
  
If the answer to the users question has been taken from Contents_2 then you need to provide Source_File_2 as an in-line citation along with the Page_Number_2
If the answer to the users question has been taken from both Contents_1 and Contents_3 then you need to provide Source_File_1 and Source_File_3 as the citations with the Page_Number_1 and Page_Number_3 along with the final answer
 
Never provide the phrase "Source_File_1" verbatim in the final answer. It is only a placeholder to help you understand the output requirements and to provide examples. 

The meaning of in-line citation has been explained below with examples.
 
Cite sources as [1] or [2] or [3] after each sentence only when necessary, not always(not just the very end) to back up your answer (Ex: Correct: [1], Correct: [2][3], Incorrect: [1, 2])
Following are examples of Correct and Incorrect Answers
 
Correct example 1:
Question: Some question here
Answer: Answer to the question. This sentence is from Contents_1 [1]. This is the second sentence from Contents_3 and Contents_3 and Contents_4 [2][3]. This is the third sentence from Contents_1 [1]. this is the fourth sentence Contents_2 [4].
  
        Sources:
            [1] Source_File_1, Page Number: Page_Number_1
            [2] Source_File_3, Page Number: Page_Number_3
            [3] Source_File_4, Page Number: Page_Number_4
            [4] Source_File_2, Page Number: Page_Number_2
 
Correct example 2:
Question: Some other question here
Answer: This is some random paragraph that answers the users question and has been rephrased from Contents_2 [1] and Contents_4 [2].
        Sources:
            [1] Source_File_2, Page Number: Page_Number_2
            [2] Source_File_4, Page Number: Page_Number_4
 
Incorrect example 1 (never do this) :
Question: Some other question here
Answer: This is the first sentence [1-3]. This is the second sentence [2,3]. This is the third sentence [1,3]. this is the fourth sentence [4,6].
 
Incorrect example 2 (never do this) :
Question: Some question here
Answer: based on the context provided from the source (1),(2) and (3) the answer can be provided
 
Sample Input/Output:
 
Question: What is U.S Real Estate Strategy?
 
Answer: The US Real Estate Strategy aims to improve the results of the US real estate book by retaining the best performing accounts and renewing based on risk characteristics and price adequacy. The strategy applies to risks located in the US, and underwriters should follow the guidance outlined in the Canadian Addendum to the US Real Estate Strategy for schedules including Canadian only locations [1].

        Sources:
            [1] Strategy for Real Estate (1).pdf; Pages 1, 2, 4
 
Question: What kinds of Hazard Classification are used by Core Logic?
Answer: No risk or low risk, moderate risk, high risk and very high risk[1]
        Sources:
            [1] Brushfire.pdf; Page 1

**No Answer Found Example**:

Question: What is the new policy for commercial real estate loans?
Answer: The answer is not available in the provided context. Please provide a better context.


In your final answer to the user query, do not write the word "Answer:". That is only to illustrate the examples.
Given the context\n
{text}\n\n
Answer the question without using any kind external information and only use the context provided. Remove duplicate instances of the "Source File", "Page Number" combinations.
If you find the same information within the context repeated multiple types, then explicitly point out the difference and cite them according to the source document
If the answer is not present in the given context just say 'Answer not in context' and prompt the user to provide more context.
Do not make up any information, provide answer only from the context provided. If you dont find any information related to question just say 'Answer not in requirement'
Always use Source_file name from the source key which is under metadata from where the data is retrieved.
Always have the Sources from where the information is fetched.
{instructions}
Any numerical or condition information given must be provide in summary.
Avoid repeating of information, provide details of what is provided below do not make up any information.
Output should be well formatted, use new line or bullets or tabular format as required.

Question: {question}

Assistant:"""


comb_template = """

Human: You are an helpful assistant, combine all the summary of {type} extracted providing all information.
provide details of what is provided below do not make up any information.
Output should be well formatted and use bullets for multiple sentences.
Retain and have the citation information from where the information is found.

{text}

Assistant:"""

prompt_consolidate = """

Human: You are an helpful Code Reviewer,you are given Insurance business Requirement Document, Code logic Description and Glossary,
we have implemented Code logic and need to verify is it as per requirement document.
Compare Code [X] and Requirement Document [Y] based on question below and provide compare details as per instruction below.
Comparing should be like the conditions mentioned, not like the code is inserting data in table and do check and compare all the values of code and requirement accurately.
Compare in detail if all conditions and its value is matching.
example if requirement mentions 3.5% interest for 5 years you should check is this is implemented in code or not

For Requirement document Retain and have the citation/sources information from where the information is found which part of document.
Format of Requirement summary could be like below/
example 1:
Requirement : This sentence is from Contents_1 [1]. This is the second sentence from Contents_3 and Contents_3 and Contents_4 [2][3]. This is the third sentence from Contents_1 [1]. this is the fourth sentence Contents_2 [4].
  
        Sources:
            [1] Source_File_1, Page Number: Page_Number_1
            [2] Source_File_3, Page Number: Page_Number_3
            [3] Source_File_4, Page Number: Page_Number_4
            [4] Source_File_2, Page Number: Page_Number_2
            
example 2:
Requirement : sentence 1. sentence 2.
        Sources:
            - Source_File_1, Page Number: Page_Number_1
provide the source detail from above

Question : {question}

Make use of Glossary provided in markdown table format for the Summarization if required. 
if any code variable conditional values are different from requirement mention the same, requirement document will not have variable name but will be in english phrases.
ALso check if the code logic is completely matching Requirement Document in term of any calculation, tenure, charges,numerical values of Insurance.
Highlight key points where the business requirement [Y] if all value and condition aligns/matches and implemented or deviates from specified code [X] (if deviates mention detail of what is implemented and what should have been as per requirement , compare and check logic accurately the condition as its value is matching in both or not).
Whole logic and its condition should match requirement document, if partially matched it is deviation in logic.
If there is deviation you must Mention detail text from both code and business requirement as sub section below for each point.

Aligned example : 
    code logic : Penalty for late payment of insurance is calculated as 5% of the premium amount
    requirement doc : if there is a late payment of the insurance premium,policy holder have to pay 5% penalty charges
    The above logic is correctly implemented as per requirement, The Logic is aligned.

Deviated example : 
    code logic : interest is calculated 5% for initial 5 years and 4% post to it
    requirement doc : interest for the user is 4% for first 6 years and then 3.5% from 7th year
    The code have difference in logic implementation as the percent and years are different, The Logic is deviated from requirement
    
If you find any logic aligned mention in aligned section else deviated, If None is find return None for that section.

If the code logic is not as per requirement document point out the exact location of requirement document.
Avoid repeating of information, provide details of what is provided below do not make up any information
Citation details must always be provided (as mentioned in output format) Chunk name only be provided for code and sources should only be provided for requirement.
Do not just provided None as answer, analyse and provide proper result there should be atleast one aligned or deviated logic

Output format should be in the following table:

| Code            | Requirement     | Difference                  |
|-----------------|-----------------|-----------------------------|
| Aligned code    | Deviated code   | Difference                  |

    Aligned logic:
        1)  code : Mention detailed info only as per "Code Description" found from [X] \n [citation of Chunk name]
        requirement: Mention requirement doc actual complete details [Y] \n [sources]
        Difference : None
                        
        2)  code : Mention detailed info only as per "Code Description" found from [X] \n [citation of Chunk name]
        requirement: Mention requirement doc actual complete details [Y] \n [sources]
        Difference : None

    Deviated Logic:
        1)  code : Give a detailed info and mention all details of chunk only as per "Code Description" found from [X] \n [citation of Chunk name]
        
        requirement: Mention requirement doc actual complete details [Y] \n [sources]

        Difference : Mention what is deviated

        2)  code :Give a detailed info and mention all details of chunk only as per "Code Description" found from [X] \n [citation of Chunk name]

        requirement: Mention requirement doc actual complete details [Y] \n [sources]

        Difference : Mention what is deviated

The above mentioned keywords ([X] [Y] [citation] [sources] [citation of Chunk name]) is place holder for your reference,do not print as it is, replace and refer to actual values corresponding to it.
example
for [sources]
        Sources:
        [1] Source_File_1, Page Number: Page_Number_1
for [citation of Chunk name]
        [Name of chunk]

Important: Return only the relevant code description as per the question. Always make sure to return difference for deviated output.
whenever Deviated logic if found you must always have code,requirement,Difference

You should strictly compare Requirement Document with "Code Documentation" which ever is relevant according to question.

In case, If information related to question is not present in either of code or requirement section, provide detail from section that is present and "No information Available" for the section where information is not found. and should be under Deviated logic.
    
[X] Code Description (Each chunk is seperated by (----------)):
---- start ----
{summary_1}
---- end ----


[Y] Requirement Document:
---- start ----
{summary_2}
---- end ----


4:
{glossary}

Output format:

| Code                                                                                      | Requirement                                                                                   | Difference           |
|-------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|----------------------|
| code: Penalty for late payment of insurance is calculated as 5% of the premium amount     | requirement: if there is a late payment of the insurance premium, policy holder has to pay 5% penalty charges | None                 |
| code: Interest is calculated 5% for initial 5 years and 4% post to it                     | requirement: Interest for the user is 4% for first 6 years and then 3.5% from 7th year        | Different percentages and years |


Ensure to replace the placeholders ([X], [Y], [citation of Chunk name], [sources]) with the actual values.
This format ensures clarity by having columns for code, requirement, and difference, with aligned and deviated logic appropriately categorized.

Assistant:"""




# Use below format only in case If information related to question is not present in either of code or requirement section, provide detail from section that is present and "No information Available" for the section where information is not found.
#     example 1:
#     Deviated Logic
#     code :Give a brief summary about the information that is present [chunk name]

#     requirement: No information Available

#     example 2:
#     Deviated Logic
#     code : No information Available

#     requirement: Give a brief summary about the information that is present [sources]
















# If there is nothing found in Aligned Logic and Deviated Logic, please return the details of whatever is available clearly mention what those details are.

# prompt_consolidate = """
#
# Human: You are an helpful Code Reviewer,you are given business Requirement Document, Code logic Summary and Glossary,
# we have implemented Code logic as per requirement document.
# Compare Code logic summary and Requirement Document.
# Make use of Glossary provided in markdown table format for the Summarization if required.
# Explain in detail which code logic is implemented and what is missing.
# if any code variable values are different from requirement mention the same.
# ALso check if the code logic is following Requirement Document.
# If the code logic is not as per requirement document point out the exact location of requirement document
# list out which part of requirement document are implemented in the code logic and which parts are not
#
#
# Glossary:
# {glossary}
#
# Code logic Summary:
# {summary_1}
#
# Requirement Document:
# {summary_2}
#
# {question}
#
# Assistant:"""



#Working

# Human: You are an helpful assistant,you are given Product Description Summary , Code Summary and Glossary,
# Code summary contain the description of the code that is made as per the product description.
# Compare Code logic summary and Product Description summary, Explain in detail the similarities and differences between the two.
# Also make use of Glossary provided in markdown table format for the Summarization