import fitz
import pandas as pd
import numpy as np
# pd.set_option('display.max_columns',20)
# pd.set_option('display.width', 150)

# doc = fitz.open(r"C:\Users\rahgoel\Python_ML\Mongo_POC\inp_doc_acko\Private-Car-Package-Policy-Wordings.pdf")
# doc = fitz.open('C:/Users/rahgoel/Python_ML/Mongo_POC/inp_doc_acko/acko-personal-health-policy-prospectus.pdf')
# doc = fitz.open('C:/Users/rahgoel/Python_ML/Mongo_POC/inp_doc_acko/prospectus-group-health-_-accident-care.pdf')
# doc = fitz.open('C:/Users/rahgoel/Python_ML/Mongo_POC/inp_doc_acko/group-personal-accident-policy-prospectus.pdf')

def get_preamble(page_text, x_min, y_min, x_max, y_max):
    # text_data = doc_page.get_text("blocks")
    # page_text = pd.DataFrame(text_data, columns=['x_1', 'y_1', 'x_2', 'y_2', 'text', 'r', 'c']).sort_values('y_2').reset_index(drop=True)

    # x_min, y_min, x_max, y_max = all_tables[0][0]['x_min'], all_tables[0][0]['y_min'], all_tables[0][0]['x_max'], all_tables[0][0]['y_max']
    tab_rec = page_text.loc[(page_text['x_1'] >= x_min) & (page_text['x_1'] <= x_max) & (page_text['y_1'] >= y_min) & (
                page_text['y_1'] <= y_max) & (page_text['x_2'] >= x_min) & (page_text['x_2'] <= x_max) & (
                                        page_text['y_2'] >= y_min) & (page_text['y_2'] <= y_max)]

    filt_page_text = page_text.loc[~((page_text['x_1'] >= x_min) & (page_text['x_1'] <= x_max) & (page_text['y_1'] >= y_min) & (
            page_text['y_1'] <= y_max) & (page_text['x_2'] >= x_min) & (page_text['x_2'] <= x_max) & (
                                    page_text['y_2'] >= y_min) & (page_text['y_2'] <= y_max))].reset_index(drop=True)

    if tab_rec.shape[0] > 0:
        if tab_rec.index[0] > 3:
            pre_sent = ''.join(page_text[tab_rec.index[0] - 3:tab_rec.index[0]]['text'].str.strip().to_list())
        else:
            pre_sent = ''.join(page_text[:tab_rec.index[0]]['text'].to_list())
        pre_sent = pre_sent.split('\n')
        if len(pre_sent) > 6:
            pre_sent = '\n'.join(pre_sent[-6:])
        else:
            pre_sent = '\n'.join(pre_sent)
        preamble_text = '[Preamble]\n' + pre_sent.lstrip()
    else:
        preamble_text = ''

    return preamble_text, filt_page_text


def remove_blank_cols(df_page):
    cols_unique = df_page.fillna('').nunique().reset_index().rename(columns={0: 'nunique'})
    table_cols = df_page.columns.to_list()
    table_cols_valid = [i for i in table_cols if i not in ['',None,'None']]


    valid_cols = cols_unique[cols_unique['nunique'] != 1].index.values.tolist()
    check_vaild_cols = cols_unique[cols_unique['nunique'] == 1].index.values.tolist()
    valid_cols_2 = [i for i in check_vaild_cols if df_page.fillna('').replace('None','').iloc[:, i].unique() != ['']]

    for i in set(check_vaild_cols) - set(valid_cols_2):
        if table_cols[i] not in ['', None] and i + 1 in valid_cols + valid_cols_2:
            table_cols[i + 1] = table_cols[i]

    df_page.columns = table_cols

    df_page = df_page.iloc[:, valid_cols + valid_cols_2]

    tot_cols = df_page.shape[1]

    if tot_cols > 2:
        temp_df = df_page.iloc[:, [0, 1]]
        if temp_df.replace('', None).dropna(axis=0).shape[0] == 0 or temp_df.replace('', None).dropna()[temp_df.replace('', None).dropna().iloc[:, -1] != temp_df.replace('', None).dropna().iloc[:, -2]].shape[0] == 0:
            col_name = ' '.join([i if i is not None else '' for i in temp_df.columns]).strip()
            df_page = df_page.iloc[:, 1:]
            # df_page.insert(0, col_name, '')
            df_page.columns = [col_name] + df_page.columns.to_list()[1:]
            df_page.iloc[:,0] = temp_df.apply(lambda x: x.iloc[1] if x.iloc[0] in [None, ''] else x.iloc[0], axis=1)

    if tot_cols > 3:
        temp_df = df_page.iloc[:, [-1, -2]]
        if temp_df.replace('', None).dropna(axis=0).shape[0] == 0 or temp_df.replace('', None).dropna()[temp_df.replace('', None).dropna().iloc[:, -1] != temp_df.replace('', None).dropna().iloc[:, -2]].shape[0] == 0:
            col_name = ' '.join([i if i is not None else '' for i in temp_df.columns]).strip()
            df_page = df_page.iloc[:, :-1]
            # df_page.insert(df_page.shape[1], col_name, '')
            df_page.columns = df_page.columns.to_list()[:-1] + [col_name]
            df_page.iloc[:, -1] = temp_df.apply(lambda x: x.iloc[1] if x.iloc[0] in [None, ''] else x.iloc[0], axis=1)

    if len(table_cols_valid) == df_page.shape[1]:
        df_page.columns = table_cols_valid

    return df_page


def get_table_split(tab_df):
    num_cells = tab_df.shape[0] * tab_df.shape[1]
    if num_cells == 0:
        return 1
    avg_cell_size = tab_df.astype(str).applymap(len).mean().mean()
    # num_splits = (num_cells * avg_cell_size) // 2000 + 1
    num_splits = round((num_cells * avg_cell_size) / 2000) + 1
    return int(num_splits)


def get_text_tables(docs):
    tab_detail = {}
    text_detail = {}
    for num,page_data in enumerate(docs):
        # print(num)
        pg_tab_list = list()
        pg_table = page_data.find_tables()
        pg_table_len = len(pg_table.tables)
        # print(pg_table_len)
        # print('-'*15)

        text_data = page_data.get_text("blocks")
        page_text = pd.DataFrame(text_data, columns=['x_1', 'y_1', 'x_2', 'y_2', 'text', 'r', 'c']).sort_values('y_2').reset_index(drop=True)

        if pg_table_len > 0:
            for tab in pg_table:
                x_min,y_min,x_max,y_max = tab.bbox
                col_cnt = tab.col_count
                df_data = tab.extract()
                row_cnt = tab.row_count
                if row_cnt > 2 and col_cnt > 1:
                    try:
                        pop_list = []
                        for i in range(0, row_cnt):
                            if set(df_data[i]) in [{None}, {'', None, None}, {''}]:
                                pop_list.append(i)
                            elif len(df_data[i]) != col_cnt:
                                df_data[i].extend(['' for i in range(0, col_cnt - len(df_data[i]))])
                        if pop_list:
                            for index in sorted(pop_list, reverse=True):
                                del df_data[index]
                        df_page = pd.DataFrame(df_data[1:],columns=df_data[0])
                    except:
                        pop_list = []
                        for i in range(0, row_cnt):
                            if set(df_data[i]) in [{None},{'',None,None},{''}]:
                                pop_list.append(i)
                            elif len(df_data[i]) != col_cnt:
                                df_data[i].extend(['' for i in range(0, col_cnt - len(df_data[i]))])
                        if pop_list:
                            for index in sorted(pop_list, reverse=True):
                                del df_data[index]
                        df_page = pd.DataFrame(df_data[1:],columns=df_data[0])

                    if df_page.shape[0] > 1:

                        preamble,page_text = get_preamble(page_text, x_min, y_min, x_max, y_max)

                        df_page = remove_blank_cols(df_page)

                        split_tables = get_table_split(df_page)

                        if split_tables > 1:
                            final_tables = np.array_split(df_page,split_tables)
                        else:
                            final_tables = [df_page]

                        # print(preamble)
                        # print(df_page.to_markdown(index=False))
                        # print('*'*20)
                        # print('\n')

                        td = dict()
                        td['x_min'] = x_min
                        td['y_min'] = y_min
                        td['x_max'] = x_max
                        td['y_max'] = y_max
                        td['table'] = final_tables
                        td['preamble'] = preamble
                        pg_tab_list.append(td)
            if len(pg_tab_list) > 0:
                tab_detail[num] = pg_tab_list
        text_detail[num] = [''.join(page_text['text'].to_list()).replace("\n", "").strip()]

    return tab_detail,text_detail


# all_tables,all_text = get_tables(doc)
